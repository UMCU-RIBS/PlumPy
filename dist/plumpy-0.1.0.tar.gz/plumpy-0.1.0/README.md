Python package to analyze BCI data from a Blackrock implant

Python 3.10.5
