__version__ = "0.1.0"
__author__ = 'Julia Berezutskaya'
__credits__ = 'UMC Utrecht'

PLUMPY_CONFIG_DIR = '/Fridge/bci/data/23-171_CortiCom/F_DataAnalysis/plumpy_configs'


